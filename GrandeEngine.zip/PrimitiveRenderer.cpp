#include"PrimitiveRenderer.h"
#include "Point2D.h"
#include "LineSegment.h"
#include<stack>
#include <iostream>
#include <vector>
#include <cmath>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
using namespace std;
#define M_PI 3.14

void PrimitiveRenderer::SetColor(ALLEGRO_COLOR color)
{
	this->Ucolor = color;
}

// Funkcja pomocnicza do pobierania koloru piksela
ALLEGRO_COLOR PrimitiveRenderer::GetPixel(int x, int y)
{
	return al_get_pixel(al_get_target_bitmap(), x, y);
}

// Funkcja pomocnicza do por�wnywania kolor�w (ze wzgl�du na struktur� ALLEGRO_COLOR)
bool PrimitiveRenderer::CompareColors(ALLEGRO_COLOR c1, ALLEGRO_COLOR c2)
{
	return c1.r == c2.r && c1.g == c2.g && c1.b == c2.b && c1.a == c2.a;
}

//// Funkcje rysuj�ce///////////////////////////////////
	//zr�b pixel
	void PrimitiveRenderer::PutPixel(int x0, int y0)
	{
		al_put_pixel(x0, y0,this->Ucolor);
		//al_flip_display();
	}

	// Rysowanie linii
	void PrimitiveRenderer::DrawLine(int x0, int y0, int x1, int y1)
	{
		int dx = abs(x1 - x0);
		int dy = abs(y1 - y0);
		int stepY = (y0 < y1) ? 1 : -1;
		int stepX = (x0 < x1) ? 1 : -1;
		int error = dx - dy;
		int error2;
		while (x0 != x1 || y0 != y1) {
			PutPixel(x0, y0);
			error2 = error + error;
			if (error2 > -dy) {
				error -= dy;
				x0 += stepX;
			}
			if (error2 < dx) {
				error += dx;
				y0 += stepY;
			}
		}
		//al_flip_display();
		cout << "Line Drawn\n";
	}

	// Rysowanie okr�gu- zwyk�a
	void PrimitiveRenderer::DrawCircle(int x0, int y0, int R)
	{
		float a, step;
		int x, y;
		step = 1.0 / R; // Jeden krok
		for (a = 0; a < 2 * M_PI; a += step) {
			x = x0 + R * cos(a) + 0.5; // Zaokr�glone X
			y = y0 + R * sin(a) + 0.5; // Zaokr�glone Y
			PutPixel(x, y);
		}
		//al_flip_display();
		cout << "Circle Drawed\n";
	}

	// Metoda rysuj�ca okr�g za pomoc� 8-krotnej symetrii (algorytm Bresenhama)
	void PrimitiveRenderer::DrawCircleSymmetry(int x0, int y0, int R)
	{
		int x = 0;
		int y = R;
		int d = 3 - 2 * R;  // Decyzyjna zmienna
		while (y >= x)
		{
			// 8-krotna symetria
			PutPixel(x0 + x, y0 + y);
			PutPixel(x0 - x, y0 + y);
			PutPixel(x0 + x, y0 - y);
			PutPixel(x0 - x, y0 - y);
			PutPixel(x0 + y, y0 + x);
			PutPixel(x0 - y, y0 + x);
			PutPixel(x0 + y, y0 - x);
			PutPixel(x0 - y, y0 - x);

			x++;
			if (d > 0)
			{
				y--;
				d = d + 4 * (x - y) + 10;
			}
			else
			{
				d = d + 4 * x + 6;
			}
		}
		//al_flip_display();
		cout << "Okrag z 8-k symetria\n";
	}

	// Rysowanie elipsy
	void PrimitiveRenderer::DrawEllipse(int x0, int y0, int Rx, int Ry)
	{
		// Ustal minimalny krok
		const float min_step = 0.01f; // Minimalny krok
		float step;

		// Oblicz krok w zale�no�ci od warto�ci promieni
		if (Rx > 0 && Ry > 0) {
			step = min_step / (Rx + Ry); // Dostosowanie kroku w oparciu o sum� promieni
		}
		else {
			step = min_step; // U�yj minimalnego kroku, je�li promienie s� zerowe
		}

		for (float angle = 0; angle < 2 * M_PI; angle += step)
		{
			int x = static_cast<int>(x0 + Rx * cos(angle) + 0.5f);  // Przemieszczenie w osi X
			int y = static_cast<int>(y0 + Ry * sin(angle) + 0.5f);  // Przemieszczenie w osi Y
			PutPixel(x, y);
		}
		//al_flip_display();
		cout << "Elipsa narysowana\n";
	}

	// Funkcja do rysowania prostok�ta
	void PrimitiveRenderer::DrawRectangle(int x0, int y0, int x1, int y1)
	{
		DrawLine(x0, y0, x0, y1);
		DrawLine(x0, y1, x1, y1);
		DrawLine(x1, y1, x1, y0);
		DrawLine(x1, y0, x0, y0);
		//al_flip_display();
		cout << "Prostokat prostokatuje\n";
	}

	// Funkcja do rysowania tr�jk�ta
	void PrimitiveRenderer::DrawTriangle(int x0, int y0, int x1, int y1, int x2, int y2)
	{
		//   al_draw_triangle(x1, y1, x2, y2, x3, y3, color, thickness);
		DrawLine(x0, y0, x1, y1);
		DrawLine(x1, y1, x2, y2);
		DrawLine(x2, y2, x0, y0);
		//al_flip_display();
		cout << "Trujkatuje\n";
	}

	//// Kolorowanie metod� - MA DZIA�A� ////////////////////////

	// Wype�niony prostok�t
	void PrimitiveRenderer::DrawFilledRectangle(int x0, int y0, int x1, int y1)
	{
		// Rysowanie prostok�ta poprzez wype�nianie go liniami poziomymi
		for (int y = y0; y <= y1; y++)
		{
			DrawLine(x0, y, x1, y); // Wype�nianie
		}
		//al_flip_display();
		cout << "Wypelniony prostokat narysowany\n";
	}

	// Funkcja do rysowania wype�nionego tr�jk�ta (metoda skan-linii)
	void PrimitiveRenderer::DrawFilledTriangle(int x0, int y0, int x1, int y1, int x2, int y2)
	{
		// Posortowanie wierzcho�k�w wed�ug wsp�rz�dnych Y (y0 <= y1 <= y2)
		if (y0 > y1) { std::swap(x0, x1); std::swap(y0, y1); }
		if (y1 > y2) { std::swap(x1, x2); std::swap(y1, y2); }
		if (y0 > y1) { std::swap(x0, x1); std::swap(y0, y1); }

		auto interpolate = [](int x0, int y0, int x1, int y1, int y) -> int
		{
			if (y1 == y0) return x0; // Unikamy dzielenia przez zero
			return x0 + (x1 - x0) * (y - y0) / (y1 - y0);
		};

		for (int y = y0; y <= y2; y++) {
			int x_start = (y <= y1) ? interpolate(x0, y0, x1, y1, y) : interpolate(x1, y1, x2, y2, y);
			int x_end = interpolate(x0, y0, x2, y2, y);
			DrawLine(x_start, y, x_end, y);
		}
		//al_flip_display();
		cout << "Wypelniony trojkat narysowany\n";
	}

	// Wype�niony okr�g (rysowanie linii poziomych dla ka�dego "ringu")
	void PrimitiveRenderer::DrawFilledCircle(int x0, int y0, int R)
	{
		for (int y = -R; y <= R; y++) {
			int dx = (int)sqrt(R * R - y * y); // Odleg�o�� pozioma dla ka�dego Y
			DrawLine(x0 - dx, y0 + y, x0 + dx, y0 + y);
		}
		//al_flip_display();
		cout << "Wypelniony okrag narysowany\n";
	}

	//// Inteligentniejsze kolorowanie - to o kt�rym wspomina� �ukawski na wyk�adzie /////////////////////////////////////

	// Border Fill Algorithm (iteracyjny)
	void PrimitiveRenderer::BorderFill(int x, int y, ALLEGRO_COLOR fillColor, ALLEGRO_COLOR borderColor)
	{
		std::stack<std::pair<int, int>> pixelStack;
		pixelStack.push({ x, y });

		while (!pixelStack.empty()) {
			std::pair<int, int> currentPixel = pixelStack.top();
			int px = currentPixel.first;
			int py = currentPixel.second;
			pixelStack.pop();

			ALLEGRO_COLOR currentColor = GetPixel(px, py);

			if (!CompareColors(currentColor, borderColor) && !CompareColors(currentColor, fillColor)) {
				PutPixel(px, py);

				pixelStack.push({ px + 1, py });
				pixelStack.push({ px - 1, py });
				pixelStack.push({ px, py + 1 });
				pixelStack.push({ px, py - 1 });
			}
		}
		cout << "Obszar wypelniony (border fill)\n";
	}

	// Flood Fill Algorithm (iteracyjny)
	void PrimitiveRenderer::FloodFill(int x, int y, ALLEGRO_COLOR fillColor)
	{
		std::stack<std::pair<int, int>> pixelStack;
		ALLEGRO_COLOR targetColor = GetPixel(x, y);

		if (CompareColors(targetColor, fillColor)) return;

		pixelStack.push({ x, y });

		while (!pixelStack.empty()) {
			std::pair<int, int> currentPixel = pixelStack.top();
			int px = currentPixel.first;
			int py = currentPixel.second;
			pixelStack.pop();

			ALLEGRO_COLOR currentColor = GetPixel(px, py);

			if (CompareColors(currentColor, targetColor)) {
				PutPixel(px, py);

				pixelStack.push({ px + 1, py });
				pixelStack.push({ px - 1, py });
				pixelStack.push({ px, py + 1 });
				pixelStack.push({ px, py - 1 });
			}
		}
		cout << "Obszar wypelniony (flood fill)\n";
	}

	//////Poligon



	// testownik
	void PrimitiveRenderer::DisplayImage(const char* filePath, float x, float y, float scaleX, float scaleY)
	{
		// Inicjalizacja modu�u do obs�ugi obraz�w, je�li jeszcze nie zosta�a wykonana
		if (!al_init_image_addon())
		{
			cerr << "Blad: Nie udalo sie zainicjalizowac dodatku do obrazow!" << endl;
			return;
		}

		// �adowanie obrazu z pliku
		ALLEGRO_BITMAP* image = al_load_bitmap(filePath);
		if (!image)
		{
			cerr << "Blad: Nie udalo sie zaladowac obrazu: " << filePath << endl;
			return;
		}

		// Skaluje obraz do podanych rozmiar�w
		int width = al_get_bitmap_width(image) * scaleX;
		int height = al_get_bitmap_height(image) * scaleY;

		// Wy�wietlanie obrazu na ekranie w okre�lonym miejscu i rozmiarze
		al_draw_scaled_bitmap(image, 0, 0, al_get_bitmap_width(image), al_get_bitmap_height(image), x, y, width, height, 0);

		// Wy�wietlanie obrazu na ekranie
		al_flip_display();

		// Usuwanie bitmapy, aby zwolni� pami��
		al_destroy_bitmap(image);
	}
