#pragma once

class GameObject {
public:
    virtual ~GameObject() = default; // Wirtualny destruktor
};
