#pragma once
#include "Point2D.h"
#include "PrimitiveRenderer.h"

class Mody
{
public:
	float x, y;

public:
	void trans();
	void rot();
	void skal();
};

